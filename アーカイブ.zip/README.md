# Numerical_analysis
```
言語　python3.11.0
実行環境　macOS 13.6 　使用ライブラリ　Numpy

```
